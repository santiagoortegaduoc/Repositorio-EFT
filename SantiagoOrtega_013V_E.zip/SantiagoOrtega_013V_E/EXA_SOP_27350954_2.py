dic_libros={'L001': ['Sombras del Sur', 'A. Rojas', 'novela', 2019, 'AndesPress', False],
    'L002': ['Python en Ruta', 'M. Diaz', 'tecnología', 2023, 'CodeBooks', True],
    'L003': ['Mar y Viento', 'C. Silva', 'poesía', 2017, 'Litoral', False],
'L004': ['Historia Breve', 'J. Pérez', 'historia', 2015, 'Cronos', False],
'L005': ['Mundos Lejanos', 'L. Torres', 'ciencia ficción', 2021, 'Orión', True],
'L006': ['Cocina Simple', 'R. Soto', 'cocina', 2018, 'Sabores', False]
}
dic_prestamos={'L001': [500, 4],
    'L002': [700, 0],
    'L003': [300, 10],
    'L004': [400, 2],
    'L005': [600, 1],
    'L006': [350, 6]
}

def copias_genero(genero):
     
     copias=0
     prestamos=0

     if len(dic_libros)==0:
        print("No hay libros ingresados")

     for g in dic_libros.values():
          if genero==dic_libros[2]:
               for c in dic_prestamos.keys():
                    if dic_prestamos.keys()==dic_libros.keys():
                         copias=dic_prestamos[1]
     
def busqueda_multa(multa_min, multa_max):
   
    resultados = []
    
    for codigo, datos_prestamo in dic_prestamos.items():
        multa = datos_prestamo[0]
        copias = datos_prestamo[1]
        
        if multa_min <= multa <= multa_max and copias > 0:
            if codigo in dic_libros:
                titulo = dic_libros[codigo][0]
                resultados.append(f"{titulo}--{codigo}")

            if len(resultados) > 0: 
                print(f"Se encontraron los libros: {resultados}")
            else:
                print("No hay libros con esa multa")

def buscar_codigo(codigo):
    
    for clave in dic_prestamos.keys():
       if codigo.upper()==clave.upper():
           return True
       else:
           return False


def actualizar_multa(codigo, nueva_multa):

    buscar_codigo(codigo)

    if buscar_codigo==True:
        dic_prestamos[0]=nueva_multa
        print("Multa Actualizada")
        return True
    else:
        return False
        print("El código no existe")


def val_codigo():

    codigo_nuevo=str(input("Ingrese el código del libro nuevo: ")).upper()

    for codigo_nuevo in dic_libros.keys():
        codigo_viejo=dic_libros.keys()
        if codigo_nuevo==codigo_viejo:
            return False
        else:
            if len(codigo_nuevo)>0 and codigo_nuevo!=" ":
                return True
        
def val_titulo():
       titulo_nuevo=str(input("Ingrese el titulo del libro nuevo: "))
       if len(titulo_nuevo)>0 and titulo_nuevo!=" ":
         return True
       else:
        return False 
        
def val_autor():
    autor=str(input("Ingrese el autor del libro nuevo: "))
    if len(autor)>0 and autor!=" ":
         return True
    else:
        return False 
    
def genero():
     gen=str(input("Ingrese el genero del libro nuevo: "))
     if len(gen)>0 and gen!=" ":
         return True
     else:
        return False 
     
def val_año():
     año=int(input("Ingrese el año de publicación del libro nuevo: "))
     if año>0:
         return True
     else:
        return False 
     
def editorial():
     edit=str(input("Ingrese la editorial del libro nuevo: "))
     if len(edit)>0 and edit!=" ":
         return True
     else:
        return False 
     
def es_novedad():
    nov=str(input("Indique si el libro es novedad (s/n): ")).lower()

    if nov=="s":
        nov=True
    elif nov=="n":
        nov=False
    else:
        print("Opción no valida")

def precio_multa_n():
    precio_multa=int(input("Ingrese el valor de la multa del libro nuevo: "))
    if precio_multa>0:
         return True
    else:
        return False
    
def copias_dispo():
    copias_disp=int(input("Ingrese el año de publicación del libro nuevo: "))
    if copias_disp>0:
         return True
    else:
        return False
    
def agregar_libro(codigo_nuevo, titulo_nuevo_, autor, gen, año, edit, nov, precio_multa, copias_disp):

    val_codigo()
    val_titulo()
    val_autor()
    genero()
    val_año()
    editorial()
    es_novedad()
    precio_multa_n()
    copias_dispo()

    if val_codigo and val_titulo and val_autor and genero and val_año and editorial and es_novedad and precio_multa_n and copias_dispo:
        ['codigo_nuevo': 'titulo_nuevo', 'autor', 'gen', 'año', 'edit', 'nov', 'precio_multa', 'copias_disp'].append(dic_libros)








        

print("""========== MENÚ PRINCIPAL ==========
1. Copias por género
2. Búsqueda de libros por rango de multa
3. Actualizar multa de libro
4. Agregar libro
5. Eliminar libro
6. Salir
=====================================""")



while True:

        opcion=int(input("Ingrese una opción 1-6: "))
        
        match opcion:
    
             case 1:
                genero=str(input("Ingrese el género que busca: ")).lower().strip()
                copias_genero(genero)

             case 2:
                while True:
                    try:
                        m_min_str = input("Ingrese multa mínima: ")
                        multa_min = int(m_min_str)
                        m_max_str = input("Ingrese multa máxima: ")
                        multa_max = int(m_max_str)
                        
                        if multa_min >= 0 and multa_max >= 0 and multa_min <= multa_max:
                            busqueda_multa(multa_min, multa_max, dic_prestamos, dic_libros)
                            break
                        else:
                            print("Debe ingresar valores enteros válidos (min <= max y mayores o iguales a 0)")
                    except ValueError:
                        print("Debe ingresar valores enteros")

             case 3:
                nueva_multa=int(input("Ingrese el valor de la nueva multa"))
                codigo=str(input("Ingrese el código del libro al que actualizará la multa"))
                actualizar_multa(codigo, nueva_multa)

             case 4:

                agregar_libro()

             case 6:
                print("Programa finalizado")
                break
